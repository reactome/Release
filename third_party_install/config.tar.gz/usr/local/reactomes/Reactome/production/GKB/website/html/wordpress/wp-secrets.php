<?php
/**
 *
 * Used for DB credentials; not under gut version control
 * @package WordPress
 */

define('WP_HOME', '/');
define('WP_SITEURL', '/wordpress');
define('DB_NAME', 'gk_wordpress');
define('DB_USER', 'reactome_user');
define('DB_PASSWORD', 'reactome_pass');
define('DB_HOST', 'localhost');
