<?php
/**
 *
 * Used for DB credentials; not under gut version control
 * @package WordPress
 */

define('WP_HOME', 'http://54.86.211.166');
define('WP_SITEURL', 'http://54.86.211.166/wordpress');
define('DB_NAME', 'gk_wordpress');
define('DB_USER', 'reactome_user');
define('DB_PASSWORD', 'reactome_pass');
define('DB_HOST', 'localhost');
